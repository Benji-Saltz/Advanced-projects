##Benji Saltz
##02/05/17
##6.Combinations and Duplicates
##Description: type combandDup() to be prompted to input letters and numbers which will be sorted into combinations and duplicates 
def combandDup():
    input_list= input("Type letters and numbers to find the combinations and duplicates, but put spaces between values: ").split()
    if type(input_list[0]) == int: ##For both types to work efficently, both int and string are checked seperately
        duplicate=[]
        combination=[]
        for i in (input_list):
            for j in (input_list):
                if i==j: ## Finds duplicates as the value if it runs twice will find its equal value
                    duplicate.append(str(i) + str(j))
                    
                else:## Creates all possible combinations
                    combination.append(str(i) + str(j))
    
        print(duplicate)
        print(combination)
    elif type(input_list[0]) == str:
        duplicate=[]
        combination=[]
        for i in (input_list):
            for j in (input_list):
                if i==j:
                    duplicate.append(str(i) + str(j))
                    
                else:
                    combination.append(str(i) + str(j))
    
        print(" The duplicates are: ",'\n',duplicate)##Prints duplicates and combinations
        print("The combinations are: ",'\n',combination)
