#Benji Saltz
#February 7th, 2018
#Question 5 - Letter Game
from random import randint as r
string='qwertyuiopasdfghjklzxcvbnm'
while True:
    letter=string[r(0,len(string))]
    print(letter)
    points=50
    while points>0:
        if points!=50:
            print('You have '+str(points)+' points.')
        while True:
            try:
                guess=str(input("Enter a word: "))
                break
            except:
                print("That is not an input work")
        if guess.count(letter)==1:
            print('There is 1 secret letter in that word')
        else:       
            print('There are '+str(guess.count(letter))+' secret letters in that word')
        if guess.count(letter)<4:
            points-=10
        elif guess.count(letter)==4:
            points-=5
        else:
            break
    if points<=0:
        print('You lose')
    else:
        print('Congratulations') 
    

        
