##Benji Saltz
##02/05/17
##Programs 1,2,3,4

##1. List of Factors
##Description: Prints factors 
for i in range(2,21):
    lst=[]
    for j in range(1,i+1):
        if i%j==0:
            lst.append(j)
    print(lst)

##2. Day of the Year
##Description: To run the program to find the day of the year, type dayYear(enter a day here, enter a month here) then run to find day of the year
days=[31,28,31,30,31,30,31,31,30,31,30,31]
def dayYear(day, month):
    final=0
    for i in range(month-1):
        final+=days[i]
    final+=day
    return final

## 3. Natural Number
##Description: Finds value e 
num1 = 1
def naturalNum(num):
    final = num
    for i in range(num-1, 0, -1):
        final *= i
    return final
for i in range(1,11):
    num1 += 1/naturalNum(i)
print("e= ",num1)

##4. Prints and Patterns
##Description: Will be prompted to write an input to be used as a pattern
word= input("Enter a word to insert into a Pattern!: ")
for i in range(len(word)):
    print(word[i:])
print()
for i in range(len(word)):
    print(" "*i+word[i:])
print()
for i in range(len(word)):
    for j in range(i):
        print(" ",end= "")
    for j in range(len(word)-i):
        if j+1 == len(word)-i:
            print(word[j])
        else:
            print(word[j]+'-',end= "")
print()
for i in range(len(word)):
    word=word[:len(word)-1]
    print(' '*i, end='')
    print(word[::-1]+ word)


        
    
            


